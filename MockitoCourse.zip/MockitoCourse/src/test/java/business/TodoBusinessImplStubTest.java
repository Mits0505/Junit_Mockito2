package business;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import data.api.TodoServiceStub;

public class TodoBusinessImplStubTest {

	@Test
	public void testRetrieveTodosRelatedToSpring() {
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(new TodoServiceStub());
		List<String> springToDos = todoBusinessImpl.retrieveTodosRelatedToSpring("Mitali");
		
		assertEquals(2,springToDos.size());
		
		assertEquals(Arrays.asList("Learn Spring","Learn Spring MVC"),springToDos);
	}

}
