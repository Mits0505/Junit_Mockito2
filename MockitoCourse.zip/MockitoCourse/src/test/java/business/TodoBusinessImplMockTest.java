package business;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import data.api.TodoService;
import data.api.TodoServiceStub;

public class TodoBusinessImplMockTest {

	@Test
	public void testRetrieveTodosRelatedToSpring() {
		
		TodoService todoService = mock(TodoService.class);
		when(todoService.retrieveTodos("Mitali")).thenReturn(Arrays.asList("Learn Spring","Learn Spring MVC","Learn to Dance"));
		
		TodoBusinessImpl todoBusinessImpl = new TodoBusinessImpl(todoService);
		
		List<String> springToDos = todoBusinessImpl.retrieveTodosRelatedToSpring("Mitali");
		
		assertEquals(2,springToDos.size());
		
		assertEquals(Arrays.asList("Learn Spring","Learn Spring MVC"),springToDos);
	}

}
